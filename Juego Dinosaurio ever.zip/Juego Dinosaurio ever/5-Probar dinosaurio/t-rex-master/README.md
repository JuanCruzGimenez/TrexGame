# T-Rex game with Processing

This repository contains the code for making our own version of Chrome's T-Rex game! Check full article at <a src = "https://iq.opengenus.org/t-rex-game-with-processing/">iq.opengenus.org/t-rex-game-with-processing/</a>


<img src = "trexgame.gif">
